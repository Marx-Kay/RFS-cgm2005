"""论文正文的模型（式 (2)(3)(5)）：按永久收入归一化，永久冲击随机游走。

价值函数用确定性等价形式 W = ((1-γ)V)^(1/(1-γ))，在 log(现金) 上做三次样条（论文附录 A）。
数值细节是自己定的：5 点求积（取教学代码 lifecycle.f90 的节点），对数等距的 301 点现金网格，
股票比例步长 0.01，消费用黄金分割连续优化。
"""
import sys
from pathlib import Path

import numpy as np
from numba import njit, prange

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "求解"))
from cgm99_port import SURVIVAL

NODES = np.array([-2.8569700138728, -1.35562617997427, 0.0, 1.35562617997426, 2.8569700138728])
WEIGHTS = np.array([0.01125741132772, 0.22207592200561, 0.53333333333333, 0.22207592200561, 0.01125741132772])
DELTA, GAMMA, LAMBDA = 0.96, 10.0, 0.68212
RF, MU, SIGR = 1.02, 0.04, 0.157
T, RETIRE = 81, 45      # 20..100 岁；t>=45（65 岁起）下一期拿退休金
NCASH, NALPHA, NSAVE = 301, 101, 3000
CASH_MAX = 60.0


def log_f(age):
    return -2.170042 + 2.700381 + 0.16818 * age - 0.0323371 / 10 * age**2 + 0.0019704 / 100 * age**3


@njit
def nat_spline(x, y):
    n = len(x)
    y2 = np.zeros(n); u = np.zeros(n)
    for i in range(1, n - 1):
        sig = (x[i] - x[i-1]) / (x[i+1] - x[i-1])
        p = sig * y2[i-1] + 2.0
        y2[i] = (sig - 1.0) / p
        u[i] = (6.0 * ((y[i+1]-y[i])/(x[i+1]-x[i]) - (y[i]-y[i-1])/(x[i]-x[i-1])) / (x[i+1]-x[i-1]) - sig*u[i-1]) / p
    for k in range(n - 2, -1, -1):
        y2[k] = y2[k] * y2[k+1] + u[k]
    return y2


@njit
def splint_uniform(x0, h, y, y2, xv):
    """等距网格上的样条；网格外线性外推。"""
    n = len(y)
    if xv <= x0:
        return y[0] + (y[1]-y[0])/h * (xv - x0)
    xmax = x0 + h*(n-1)
    if xv >= xmax:
        return y[n-1] + (y[n-1]-y[n-2])/h * (xv - xmax)
    lo = min(int((xv - x0) / h), n - 2)
    a = (x0 + h*(lo+1) - xv) / h
    b = 1.0 - a
    return a*y[lo] + b*y[lo+1] + ((a**3-a)*y2[lo] + (b**3-b)*y2[lo+1]) * h*h/6.0


@njit
def eval_W(lx0, lh, W, W2, x, cash_max):
    """超出现金上界时按现金线性外推（W 对现金近似一次齐次）。"""
    if x > cash_max:
        lxm = lx0 + lh*(len(W)-1)
        wm = splint_uniform(lx0, lh, W, W2, lxm)
        wl = splint_uniform(lx0, lh, W, W2, lxm - 1e-4)
        slope = (wm - wl) / (cash_max - np.exp(lxm - 1e-4))
        return wm + slope * (x - cash_max)
    return splint_uniform(lx0, lh, W, W2, np.log(x))


@njit(parallel=True)
def q_table(sgrid, agrid, lx0, lh, W, W2, cash_max, retired, G, perm, trans, rets, w3, w1):
    """Q[a, s] = E[(G·N·W'(x'))^(1-γ)]，不含生存概率。"""
    na, ns = len(agrid), len(sgrid)
    Q = np.empty((na, ns))
    for ia in prange(na):
        a = agrid[ia]
        for js in range(ns):
            s = sgrid[js]
            acc = 0.0
            for k in range(len(rets)):
                rp = RF*(1.0-a) + rets[k]*a
                if retired:
                    acc += w1[k] * eval_W(lx0, lh, W, W2, rp*s + LAMBDA, cash_max) ** (1.0-GAMMA)
                else:
                    for ip in range(len(perm)):
                        gn = G*perm[ip]
                        for it in range(len(trans)):
                            x1 = rp*s/gn + trans[it]
                            acc += w3[ip, k, it] * (gn*eval_W(lx0, lh, W, W2, x1, cash_max)) ** (1.0-GAMMA)
            Q[ia, js] = acc
    return Q


@njit
def interp_logq(tgrid, logQ, s):
    t = np.log(s + 1e-3)
    h = tgrid[1]-tgrid[0]
    lo = int((t - tgrid[0]) / h)
    b = (t - tgrid[lo]) / h
    return np.exp((1.0-b)*logQ[lo] + b*logQ[lo+1])


@njit(parallel=True)
def optimize(cash, agrid, tgrid, logQ, p):
    """逐现金点、逐股票比例，用黄金分割找最优储蓄，再和 s=0 的边角比较。目标函数在 1-γ<0 下取最小。"""
    n, na = len(cash), len(agrid)
    Wn = np.empty(n); Cn = np.empty(n); An = np.empty(n)
    gr = (np.sqrt(5.0)-1.0)/2.0
    for i in prange(n):
        x = cash[i]
        best, bc, ba = 1e300, 0.0, 0.0
        for ia in range(na):
            lo, hi = 0.0, x*(1.0-1e-9)
            for _ in range(80):
                m1 = hi - gr*(hi-lo); m2 = lo + gr*(hi-lo)
                f1 = (1-DELTA)*(x-m1)**(1-GAMMA) + DELTA*p*interp_logq(tgrid, logQ[ia], m1)
                f2 = (1-DELTA)*(x-m2)**(1-GAMMA) + DELTA*p*interp_logq(tgrid, logQ[ia], m2)
                if f1 < f2: hi = m2
                else: lo = m1
            s = 0.5*(lo+hi)
            f = (1-DELTA)*(x-s)**(1-GAMMA) + DELTA*p*interp_logq(tgrid, logQ[ia], s)
            f0 = (1-DELTA)*x**(1-GAMMA) + DELTA*p*interp_logq(tgrid, logQ[ia], 0.0)
            if f0 <= f:
                f, s = f0, 0.0
            if f < best:
                best, bc, ba = f, x-s, agrid[ia]
        Wn[i] = best ** (1.0/(1.0-GAMMA)); Cn[i] = bc; An[i] = ba
    return Wn, Cn, An


def solve(sig_u, sig_e):
    """返回归一化现金网格和各年龄的策略 C、A（行：现金，列：t=0..80，对应 20..100 岁）。"""
    lcash = np.linspace(np.log(0.25), np.log(CASH_MAX), NCASH)
    cash = np.exp(lcash)
    lx0, lh = lcash[0], lcash[1]-lcash[0]
    agrid = np.linspace(0, 1, NALPHA)
    tgrid = np.linspace(np.log(1e-3), np.log(1.5*CASH_MAX+1e-3), NSAVE)
    sgrid = np.exp(tgrid) - 1e-3; sgrid[0] = 0.0
    rets = RF + MU + NODES*SIGR
    perm = np.exp(NODES*sig_u); trans = np.exp(NODES*sig_e)
    w3 = np.einsum("i,j,k->ijk", WEIGHTS, WEIGHTS, WEIGHTS)
    G = np.exp(np.diff(log_f(np.arange(20, 66))))       # G[t]：t 到 t+1 的增长，t=0..44

    W = np.empty((NCASH, T)); C = np.empty((NCASH, T)); A = np.empty((NCASH, T))
    C[:, T-1] = cash; A[:, T-1] = 0.0
    W[:, T-1] = (1-DELTA)**(1/(1-GAMMA)) * cash
    for t in range(T-2, -1, -1):
        W2 = nat_spline(lcash, W[:, t+1])
        retired = t >= RETIRE
        Q = q_table(sgrid, agrid, lx0, lh, W[:, t+1], W2, cash[-1], retired,
                    1.0 if retired else G[t], perm, trans, rets, w3, WEIGHTS)
        W[:, t], C[:, t], A[:, t] = optimize(cash, agrid, tgrid, np.log(Q), SURVIVAL[t])
    return cash, C, A
