"""两个求解和模拟一致的版本，用来和 ../模拟与画图/cgm99_figures.py 的结果对照。

A. 存档代码模型（../figures/存档代码模型/）：cgm99 原样求解（永久冲击每年重抽、不累积，在现金水平上做样条），
   模拟也不累积。cgm99 没有模拟程序，模拟按它的求解设定写出。
B. 论文随机游走模型（../figures/论文随机游走模型/）：按论文正文的归一化模型求解（paper_rw_solver.py），
   永久冲击累积，模拟同一模型。这里按永久收入缩放策略是模型本身的含义。
"""
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "模拟与画图"))
import cgm99_figures as F
import paper_rw_solver


def paper_policy():
    """把归一化策略换成 v=0 那户的千美元策略：P_t = exp(f(t))（退休后 exp(f(65))），C(X) = P_t·c(X/P_t)，α(X) = a(X/P_t)。"""
    xn, cn, an = paper_rw_solver.solve(F.SIG_U, F.SIG_E)
    cash = 4.0 + np.arange(1601.0)
    P = np.exp(F.log_f(np.minimum(F.AGES, 65)))
    C = np.empty((len(cash), F.T))
    A = np.empty((len(cash), F.T))
    for t in range(F.T):
        q = np.log(np.clip(cash / P[t], xn[0], xn[-1]))
        C[:, t] = P[t] * np.interp(q, np.log(xn), cn[:, t])
        A[:, t] = np.interp(q, np.log(xn), an[:, t])
        C[cash / P[t] < xn[0], t] = cash[cash / P[t] < xn[0]]     # 低于归一化网格下界：全部消费
    C = np.minimum(C, cash[:, None])
    return cash, C, np.where(cash[:, None] - C > 1e-6, A, 1.0)


if __name__ == "__main__":
    archive = F.policy(401, log_interp=False)
    F.run(archive, archive, "iid", "存档代码模型")
    paper = paper_policy()
    F.run(paper, paper, "rw", "论文随机游走模型")
