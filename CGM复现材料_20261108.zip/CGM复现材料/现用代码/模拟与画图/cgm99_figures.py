"""论文图 2、图 3：调用 ../求解/cgm99_port.py 的策略，模拟 10000 人，画图并打印与原图的对照。全部跑完约 1 分钟。

口径（参数都取论文 Table 4）：
  图 2：cgm99 原网格 4..404，价值函数在 log(现金) 上做样条（论文附录 A）。
  图 3：永久冲击累积（论文式 (3)），退休收入 λ·exp(f(65)+v_65)（式 (5)）。cgm99 的策略是在 v=0 的收入水平上
        解出的，永久收入为 exp(v) 的人按比例缩放：C = e^v·c(X/e^v)，α = a(X/e^v)（教学代码 lifecycle.f90 的模拟即如此）。
        现金网格放宽到 4..1604，否则网格上端的股票比例会塌下来，且缩放后有人落到网格外。
  3B：每户以当前永久收入状态预测未来收入，按 R_f 贴现、乘生存概率（论文第 5.2 节的说法；作者怎么画 3B 没有代码可查）。
      比例线除以手头现金 X：论文正文这样写，图例和图注写 W；X 的形状更接近原图。
  储蓄为 0 时股票比例无定义（论文脚注 10）：图 2 画成 1，图 3C 只统计储蓄为正的人。
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "求解"))
from cgm99_port import SURVIVAL, solve

FIGURES = HERE.parent / "figures"
RF, MU, SIGR, LAMBDA, GAMMA = 1.02, 0.04, 0.157, 0.68212, 10.0
SIG_E, SIG_U = np.sqrt(0.0738), np.sqrt(0.01065)
T, NWORK = 81, 46          # 20..100 岁；20..65 岁工作
AGES = np.arange(20, 101)

# 原图读数：图 2 的键是（年龄, 现金），图 3 的键是年龄
PAPER_2A = {(99, 50): .33, (99, 150): .21, (99, 300): .19}
PAPER_2B = {(20, 50): .48, (20, 150): .29, (20, 300): .25, (30, 50): 1, (30, 150): .99, (30, 300): .61,
            (55, 50): 1, (55, 150): .88, (55, 300): .50, (75, 50): 1, (75, 150): .56, (75, 300): .38}
PAPER_2C = {(85, 300): 44, (35, 300): 37, (20, 300): 35.5, (65, 300): 33,
            (85, 50): 22, (35, 50): 27, (20, 50): 22, (65, 50): 20}
PAPER_3 = {
    "财富": {30: 15, 40: 55, 50: 110, 60: 185, 65: 220, 80: 110, 90: 45},
    "收入": {20: 17, 40: 31, 64: 33, 70: 22},
    "消费": {20: 15, 40: 31, 65: 35, 90: 30},
    "NPV": {20: 520, 33: 590, 50: 510, 65: 350, 80: 265, 90: 140},
    "股票比例均值": {20: .95, 40: .99, 45: .95, 50: .85, 55: .73, 60: .62, 65: .50, 75: .55, 85: .60, 95: .65},
    "股票比例5%": {20: .88, 40: .95, 45: .85, 50: .65, 55: .52, 60: .42, 65: .35, 75: .38, 85: .42, 95: .50},
    "股票比例95%": {60: 1.0, 65: .78, 70: .87, 75: 1.0, 95: 1.0},
}


def log_f(age):
    return -2.170042 + 2.700381 + 0.16818 * age - 0.0323371 / 10 * age**2 + 0.0019704 / 100 * age**3


def policy(ncash, log_interp=True):
    cash, C, A = (x.astype(float) for x in solve(ncash, log_interp))
    return cash, C, np.where(cash[:, None] > C, A, 1.0)


def simulate(cash, C, A, income, nsim=10000, seed=20261029):
    """income="rw"：永久冲击累积，策略按 exp(v) 缩放；income="iid"：永久冲击每年重抽，不累积、不缩放。"""
    rng = np.random.default_rng(seed)

    def antithetic():
        z = rng.standard_normal((T, nsim // 2))
        return np.concatenate([z, -z], axis=1)

    u, e, r = antithetic() * SIG_U, antithetic() * SIG_E, antithetic() * SIGR
    if income == "rw":
        shock = np.cumsum(u[:NWORK], axis=0)
        v = np.vstack([shock, np.tile(shock[-1], (T - NWORK, 1))])    # 退休后固定在 v_65
    else:
        shock = u[:NWORK]
        v = np.zeros((T, nsim))
    Y = np.empty((T, nsim))
    Y[:NWORK] = np.exp(log_f(AGES[:NWORK])[:, None] + e[:NWORK] + shock)
    Y[NWORK:] = LAMBDA * np.exp(log_f(65) + v[NWORK:])

    W, Cs = np.zeros((T, nsim)), np.zeros((T, nsim))
    share = np.full((T, nsim), np.nan)
    w = np.zeros(nsim)
    for t in range(T):
        x = w + Y[t]
        scale = np.exp(v[t])
        q = x / scale
        c = np.interp(q, cash, C[:, t])
        above = q > cash[-1]                     # 网格外按最后一段斜率外推
        c[above] += (C[-1, t] - C[-2, t]) * (q[above] - cash[-1])
        c = np.minimum(c * scale, x)
        a = np.interp(q, cash, A[:, t])
        s = x - c
        W[t], Cs[t] = w, c
        share[t, s > 1e-6] = a[s > 1e-6]
        if t < T - 1:
            w = s * (RF * (1 - a) + (RF + MU + r[t + 1]) * a)
    return dict(Y=Y, W=W, C=Cs, share=share, v=v)


def household_npv(sim, income):
    """每户未来收入的现值：Σ_{k>t} 活到 k 岁的概率 × E_t[Y_k] / R_f^(k−t)。

    rw：工作期 E_t[Y_k] = exp(f(k) + v_t + (k−t)σ_u²/2 + σ_ε²/2)，退休金 λ·exp(f(65) + v_t + (45−t)σ_u²/2)，
    所以 NPV_t = exp(v_t) × D_t，D_t 各户相同。iid：永久冲击不延续，v_t = 0。
    """
    D = np.zeros(T)
    for t in range(T - 1):
        discount = 1.0
        for k in range(t + 1, T):
            discount *= SURVIVAL[k - 1] / RF
            if k < NWORK:
                g = (k - t if income == "rw" else 1) * SIG_U**2 / 2
                D[t] += discount * np.exp(log_f(AGES[k]) + g + SIG_E**2 / 2)
            else:
                g = max(NWORK - 1 - t, 0) * SIG_U**2 / 2 if income == "rw" else 0.0
                D[t] += discount * LAMBDA * np.exp(log_f(65) + g)
    return D[:, None] * np.exp(sim["v"])


plt.rcParams.update({
    "font.family": "Arial", "font.size": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "axes.grid.axis": "y",
    "grid.color": "black", "grid.linewidth": 0.6,
    "legend.frameon": True, "legend.edgecolor": "black", "legend.fancybox": False,
})
THIN = dict(color="black", lw=0.7)
MEDIUM = dict(color="black", lw=1.3)
THICK = dict(color="black", lw=2.2)
DOTTED = dict(color="0.35", lw=1.0, ls=(0, (1, 1.5)))
DASHDOT = dict(color="black", lw=1.0, ls=(0, (6, 2, 1, 2)))


def finish(ax, letter, xlabel, ncol):
    ax.text(-0.1, 1.06, f"({letter})", transform=ax.transAxes)
    ax.set_xlabel(xlabel)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=ncol, fontsize=7,
              handlelength=3, borderpad=0.3, columnspacing=1.2)


def figure2(cash, C, A, out):
    fig, axes = plt.subplots(3, 1, figsize=(5.2, 9.6))
    cash_axis = dict(xlim=(0, 300), xticks=np.arange(0, 301, 25))

    ax = axes[0]
    ax.plot(cash, A[:, 79], label="Age 99", **DOTTED)
    ax.axhline(MU / (GAMMA * SIGR**2), label="Complete markets", **THIN)
    ax.set(ylim=(0, 1.1), yticks=np.arange(0, 1.01, 0.2), **cash_axis)
    finish(ax, "A", "Cash-on-hand", 2)

    ax = axes[1]
    for age, style in ((20, MEDIUM), (30, THIN), (55, DOTTED), (75, THICK)):
        ax.plot(cash, A[:, age - 20], label=f"Year {age}", **style)
    ax.set(ylim=(0, 1.1), yticks=np.arange(0, 1.01, 0.2), **cash_axis)
    finish(ax, "B", "Cash-on-hand", 4)

    ax = axes[2]
    for age, style in ((85, DOTTED), (65, THICK), (35, THIN), (20, MEDIUM)):
        ax.plot(np.r_[0, cash], np.r_[0, C[:, age - 20]], label=f"Year {age}", **style)
    ax.set(ylim=(0, 50), ylabel="Thousands of 1992 US dollars", **cash_axis)
    finish(ax, "C", "Cash-on-hand", 4)

    fig.tight_layout(h_pad=2.0)
    fig.savefig(out, dpi=200)
    plt.close(fig)


def figure3(sim, npv_mean, ratio, out):
    fig, axes = plt.subplots(3, 1, figsize=(5.2, 9.6))

    ax = axes[0]
    ax.plot(AGES, sim["C"].mean(1), label="Consumption", **DOTTED)
    ax.plot(AGES, sim["Y"].mean(1), label="Income", **THIN)
    ax.plot(AGES, sim["W"].mean(1), label="Wealth", **DASHDOT)
    ax.set(ylim=(0, 250), xlim=(20, 100), xticks=np.arange(20, 101, 5))
    finish(ax, "A", "Age", 3)

    ax = axes[1]
    m = slice(0, T - 1)                       # 20..99 岁
    ax.plot(AGES[m], npv_mean[m], label="Mean NPV(Y)", **THIN)
    top = 200 * np.ceil(npv_mean[m].max() * 1.05 / 200)
    ax.set(xlim=(18, 100), xticks=np.arange(20, 96, 5), ylim=(0, max(700, top)),
           ylabel="Thousands of 1992 US dollars")
    ax.yaxis.set_major_locator(plt.MaxNLocator(7))
    ax2 = ax.twinx()
    ax2.spines["right"].set_visible(True)
    ax2.grid(False)
    ax2.plot(AGES[m], ratio[m], label="Mean[NPV(Y)/X]", **DOTTED)
    ax2.set(ylim=(0, 35), ylabel="Ratio")
    handles = ax.get_lines() + ax2.get_lines()
    ax.text(-0.1, 1.06, "(B)", transform=ax.transAxes)
    ax.set_xlabel("Age")
    ax.legend(handles=handles, labels=[h.get_label() for h in handles], loc="upper center",
              bbox_to_anchor=(0.5, -0.2), ncol=2, fontsize=7, handlelength=3, borderpad=0.3)

    ax = axes[2]
    share = sim["share"][m]
    ax.plot(AGES[m], np.nanmean(share, 1), label="Mean", **THIN)
    ax.plot(AGES[m], np.nanpercentile(share, 5, 1), label="5th percentile", **DASHDOT)
    ax.plot(AGES[m], np.nanpercentile(share, 95, 1), label="95th percentile", **DOTTED)
    ax.set(xlim=(20, 100), xticks=np.arange(20, 96, 5), ylim=(0, 1.1), yticks=np.arange(0, 1.01, 0.2))
    finish(ax, "C", "Age", 3)

    fig.tight_layout(h_pad=2.0)
    fig.savefig(out, dpi=200)
    plt.close(fig)


def compare(name, ours, paper):
    print(f"  {name}（我们/原图）:", "  ".join(f"{k}: {ours(k):.2f}/{v}" for k, v in paper.items()))


def run(fig2_policy, sim_policy, income, folder):
    """画一个版本的图 2、图 3，并打印与原图的对照。"""
    out = FIGURES / folder
    out.mkdir(exist_ok=True)
    sim = simulate(*sim_policy, income)
    npv = household_npv(sim, income)
    npv_mean = npv.mean(1)
    ratio = (npv / (sim["W"] + sim["Y"])).mean(1)

    cash, C, A = fig2_policy
    figure2(cash, C, A, out / "figure2.png")
    figure3(sim, npv_mean, ratio, out / "figure3.png")

    print("=====", out)
    alpha = lambda k: np.interp(k[1], cash, A[:, k[0] - 20])
    consumption = lambda k: np.interp(k[1], cash, C[:, k[0] - 20])
    compare("2A", alpha, PAPER_2A)
    compare("2B", alpha, PAPER_2B)
    compare("2C", consumption, PAPER_2C)
    share = sim["share"][:T - 1]
    stats = {"财富": sim["W"].mean(1), "收入": sim["Y"].mean(1), "消费": sim["C"].mean(1), "NPV": npv_mean,
             "股票比例均值": np.nanmean(share, 1), "股票比例5%": np.nanpercentile(share, 5, 1),
             "股票比例95%": np.nanpercentile(share, 95, 1)}
    for name, paper in PAPER_3.items():
        compare(name, lambda age: stats[name][age - 20], paper)
    print("  Mean[NPV/X]:", {age: round(float(ratio[age - 20]), 2) for age in (21, 32, 50, 65, 80, 92)})


if __name__ == "__main__":
    run(policy(401), policy(1601), "rw", "复现结果")
