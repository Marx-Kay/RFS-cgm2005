"""cgm99（CGM 2005 论文版 Fortran）求解部分的逐行 float32 移植。

注释里的"MAIN 第 n 行"指 ../作者代码/GitHub存档_论文原始代码cgm99/标准版_20191022/MAIN.f90。
千美元水平值、3 点求积、搜索窗口、MAXLOC 取第一个最大值、下期 cash 截断在网格内，都照原代码。
"""
import numpy as np
from numba import njit, prange

# 20..99 岁每年活到下一年的概率（MAIN 第 131-210 行）
SURVIVAL = np.array([
    0.99845, 0.99839, 0.99833, 0.9983, 0.99827, 0.99826, 0.99824, 0.9982, 0.99813, 0.99804,
    0.99795, 0.99785, 0.99776, 0.99766, 0.99755, 0.99743, 0.9973, 0.99718, 0.99707, 0.99696,
    0.99685, 0.99672, 0.99656, 0.99635, 0.9961, 0.99579, 0.99543, 0.99504, 0.99463, 0.9942,
    0.9937, 0.99311, 0.99245, 0.99172, 0.99091, 0.99005, 0.98911, 0.98803, 0.9868, 0.98545,
    0.98409, 0.9827, 0.98123, 0.97961, 0.97786, 0.97603, 0.97414, 0.97207, 0.9697, 0.96699,
    0.96393, 0.96055, 0.9569, 0.9531, 0.94921, 0.94508, 0.94057, 0.9357, 0.93031, 0.92424,
    0.91717, 0.90922, 0.90089, 0.89282, 0.88503, 0.87622, 0.86576, 0.8544, 0.8423, 0.82942,
    0.8154, 0.80002, 0.78404, 0.76842, 0.75382, 0.73996, 0.72464, 0.71057, 0.6961, 0.6809,
])


f32 = np.float32
TB, TR, TD = 20, 65, 100                  # MAIN 第 13 行
TN = TD - TB + 1                          # 81 期
NQP, NALFA, NCASH, NC = 3, 101, 401, 1501   # MAIN 第 17 行
INF = f32(-1e10)                          # MAIN 第 18 行 infinity


@njit
def spline(x, y, yp1):
    """spline.f90：三次样条二阶导数；左端导数 yp1，右端自然边界。
    原代码在现金水平上插值，yp1 = x(1)^(-gam)，即 CRRA 边际效用。"""
    n = len(x); y2 = np.empty(n, np.float32); u = np.empty(n, np.float32)
    y2[0] = f32(-0.5)
    u[0] = (f32(3.0) / (x[1] - x[0])) * ((y[1] - y[0]) / (x[1] - x[0]) - yp1)
    for i in range(1, n - 1):
        sig = (x[i] - x[i-1]) / (x[i+1] - x[i-1])
        p = sig * y2[i-1] + f32(2.0)
        y2[i] = (sig - f32(1.0)) / p
        u[i] = (f32(6.0) * ((y[i+1]-y[i])/(x[i+1]-x[i]) - (y[i]-y[i-1])/(x[i]-x[i-1])) / (x[i+1]-x[i-1]) - sig*u[i-1]) / p
    y2[n-1] = f32(0.0)
    for k in range(n - 2, -1, -1):
        y2[k] = y2[k] * y2[k+1] + u[k]
    return y2


@njit
def splint(xa, ya, y2a, x):
    """splint.f90：二分查找区间后做样条插值（不截断输出）。"""
    klo, khi = 0, len(xa) - 1
    while khi - klo > 1:
        k = (khi + klo) // 2
        if xa[k] > x: khi = k
        else: klo = k
    h = xa[khi] - xa[klo]
    a = (xa[khi] - x) / h; b = (x - xa[klo]) / h
    return a*ya[klo] + b*ya[khi] + ((a**3 - a)*y2a[klo] + (b**3 - b)*y2a[khi]) * (h*h) / f32(6.0)


@njit
def ntoi(value, grid):
    """ntoi.f90：等距网格上四舍五入找最近格点下标（这里从 0 起计）。"""
    n = len(grid)
    aux = min(max(value, grid[0]), grid[n-1])
    step = (grid[n-1] - grid[0]) / f32(n - 1)
    return int(np.rint((aux - grid[0]) / step + f32(1.0))) - 1


@njit(parallel=True)
def period(t, retired, gcash, sx, logx, gc, u, galfa, gret, weig, rf, v1n, secd, c1, a1, incs, iprob, d2):
    """一期的网格搜索。退休期对应 MAIN 第 279-360 行，工作期对应第 386-453 行。
    c1、a1、v1n 是下一期（t+1）的策略和价值。"""
    ncash = len(gcash)
    v2 = np.empty(ncash, np.float32); c2 = np.empty(ncash, np.float32); a2 = np.empty(ncash, np.float32)
    for ind2 in prange(ncash):
        x = gcash[ind2]
        # 消费搜索窗口：围绕下一期同一 cash 点的消费（MAIN 第 280-301 / 387-393 行）
        if retired:
            if t == TN - 1:
                lowc = c1[ind2] / f32(2.0); highc = c1[ind2]
                if x >= 50: highc = c1[ind2] / f32(1.5)
            elif t == TN - 2:
                lowc = c1[ind2] / f32(2.5); highc = c1[ind2]
                if x >= 50: highc = c1[ind2] / f32(1.2)
            elif t < TN - 2 and t > TN - 5:
                lowc = c1[ind2] / f32(3.5); highc = c1[ind2]
                if x >= 50: highc = c1[ind2] / f32(1.1)
            else:
                lowc = c1[ind2] - f32(10.0); highc = c1[ind2] + f32(10.0)
        else:
            if t < TR - 19 and t > TR - 25:      # t=41..45，即 60-64 岁
                lowc = c1[ind2] - f32(10.0); highc = c1[ind2] + f32(10.0)
            else:
                lowc = c1[ind2] - f32(5.0); highc = c1[ind2] + f32(5.0)
        lc2 = ntoi(lowc, gc); hc2 = ntoi(highc, gc)
        # 股票比例搜索窗口：cash>40 时只在下一期比例 ±0.2 内找（MAIN 第 307-314 行）
        la2, ha2 = 0, NALFA - 1
        if x > 40.0 and t < TN - 1:
            la2 = ntoi(a1[ind2] - f32(0.2), galfa); ha2 = ntoi(a1[ind2] + f32(0.2), galfa)
        best = f32(-np.inf); bc = 0; ba = 0
        for ia in range(la2, ha2 + 1):            # MAXLOC 按列优先取第一个最大值：alpha 外层、c 内层
            al = galfa[ia]
            for ic in range(lc2, hc2 + 1):
                inv = x - gc[ic]                  # 储蓄（MAIN 第 320 行 invest）
                uu = u[ic] if inv >= 0 else INF   # 第 326-332 行：储蓄为负不可行
                inv = max(inv, f32(0.0))
                uu = max(uu, INF)                 # 第 338 行：也把 c=0 的 -inf 效用截到 -1e10
                v1 = f32(0.0)
                for k in range(len(gret)):        # 股票收益节点（第 343-347 行）
                    nw = inv * (gret[k]*al + rf*(f32(1.0) - al))   # fci.f90：下期金融财富
                    nv = f32(0.0)
                    for m in range(len(incs)):    # EV.f90 / EVR.f90：对下期收入求期望
                        xx = min(max(incs[m] + nw, gcash[0]), gcash[ncash-1])
                        xq = np.log(xx) if logx else xx     # sx 是样条的横坐标：现金或 log(现金)
                        nv += iprob[m] * splint(sx, v1n, secd, xq)
                    v1 += nv * weig[k]
                vv = max(uu + d2 * v1, INF)       # 第 350-351 行：u(c) + δ·p_t·E[V_{t+1}]
                if vv > best:
                    best = vv; bc = ic; ba = ia
        v2[ind2] = best; c2[ind2] = gc[bc]; a2[ind2] = galfa[ba]
    return v2, c2, a2


def solve(ncash=NCASH, log_interp=False):
    """ncash=401 即原代码的 4..404；放宽时消费网格同步加长，步长不变。
    log_interp=True：按论文附录 A 在 log(现金) 上做样条（原代码在现金水平上做），左端导数换成 dV/dlogX = X^(1-γ)。"""
    nc = NC + 4 * (ncash - NCASH)
    # 参数（MAIN 第 18-22 行）
    delta, gamma, rf, sigma_r, exc, ret_fac = f32(0.96), f32(10.0), f32(1.02), f32(0.157)**2, f32(0.04), f32(0.68212)
    a, b1, b2, b3 = f32(-2.170042+2.700381), f32(0.16818), f32(-0.0323371/10), f32(0.0019704/100)
    sigt_y, sigp_y = f32(0.0738), f32(0.01065)
    # 3 点 Gauss-Hermite（MAIN 第 120-125 行）
    weig = np.array([0.1666666666666, 0.6666666666666, 0.1666666666666], np.float32)
    grid = np.array([-1.73205080756887, 0.0, 1.73205080756887], np.float32)
    delta2 = delta * SURVIVAL.astype(np.float32)           # 第 212 行
    gret = (exc + rf) + grid * sigma_r**f32(0.5)           # 第 220、223 行：股票总收益节点
    expeyp = np.exp(grid * sigp_y**f32(0.5))               # 第 221、225 行：exp(永久冲击)
    eyt = grid * sigt_y**f32(0.5)                          # 第 222 行：暂时冲击
    # 网格（第 231-241 行）
    galfa = (np.arange(NALFA, dtype=np.float32)) / f32(NALFA - 1)
    gcash = f32(4.0) + np.arange(ncash, dtype=np.float32)
    gc = f32(0.0) + np.arange(nc, dtype=np.float32) * f32(0.25)
    # 收入（第 248-254 行）：f_y(:,t) 是 20+t 岁的 exp(f)·exp(暂时冲击)，退休收入用 65 岁的 exp(f)
    f_y = np.empty((NQP, TR - TB), np.float32)
    for age in range(TB + 1, TR + 1):
        avg = np.exp(a + b1*f32(age) + b2*f32(age)**2 + b3*f32(age)**3)
        f_y[:, age - TB - 1] = avg * np.exp(eyt)
    ret_y = ret_fac * avg
    # 终期：100 岁把 cash 全部消费掉（第 262-265 行）
    with np.errstate(divide="ignore"):
        u = gc ** (f32(1.0) - gamma) / (f32(1.0) - gamma)  # utility.f90；c=0 处为 -inf
    v1 = gcash ** (f32(1.0) - gamma) / (f32(1.0) - gamma); c1 = gcash.copy(); a1 = np.zeros(ncash, np.float32)
    C = np.zeros((ncash, TN), np.float32); A = np.zeros((ncash, TN), np.float32)
    C[:, TN-1] = c1
    # 倒推：t=80..46 退休循环（第 274-375 行），t=45..1 工作循环（第 382-468 行）；t 期年龄 19+t
    sx = np.log(gcash) if log_interp else gcash
    yp1 = gcash[0] ** (f32(1.0) - gamma) if log_interp else gcash[0] ** (-gamma)
    for t in range(80, 0, -1):
        secd = spline(sx, v1, yp1)
        retired = t >= 46
        if retired:
            incs = np.array([ret_y], np.float32); iprob = np.array([1.0], np.float32)
        else:
            # EV.f90：下期收入 = exp(f)·exp(暂时冲击)·exp(永久冲击)，永久冲击不进入状态、不累积
            incs = np.array([f_y[i, t-1]*expeyp[j] for i in range(NQP) for j in range(NQP)], np.float32)
            iprob = np.array([weig[i]*weig[j] for i in range(NQP) for j in range(NQP)], np.float32)
        v1, c1, a1 = period(t, retired, gcash, sx, log_interp, gc, u, galfa, gret, weig, rf, v1, secd, c1, a1, incs, iprob, delta2[t-1])
        C[:, t-1] = c1; A[:, t-1] = a1
    return gcash, C, A
